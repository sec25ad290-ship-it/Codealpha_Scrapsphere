# ScrapeSphere – Smart Web Data Extractor

A runnable educational web-scraping website built with Flask, BeautifulSoup, Requests, HTML, CSS and JavaScript.

## Run in VS Code (Windows)

1. Install Python 3.10 or newer.
2. Extract this ZIP and open the `ScrapeSphere` folder in VS Code.
3. Open the VS Code terminal in this folder.
4. Create a virtual environment (recommended):

   ```powershell
   python -m venv venv
   .\venv\Scripts\activate
   ```

5. Install dependencies:

   ```powershell
   pip install -r requirements.txt
   ```

6. Start the website:

   ```powershell
   python app.py
   ```

7. Open your browser at `http://127.0.0.1:5000`.

## Features
- Multi-page responsive dashboard with working sidebar navigation.
- Scrapes public HTML pages with Requests and BeautifulSoup.
- Extracts title, meta description, headings, paragraphs, absolute links and image alt text.
- Displays scraped results and searchable page preview.
- Tracks job history and basic analytics.
- Exports all successful results as CSV or JSON.

## Important notes
- This starter stores results in server memory. Restarting Flask clears the jobs and results.
- This version does not include user accounts or MongoDB Atlas yet.
- Some websites block automated requests or require JavaScript rendering; those pages may not scrape with Requests.
- Use only websites you are permitted to access. Respect robots.txt, terms of service, copyright, privacy and reasonable request rates. The app checks robots.txt where it can and makes one request per submitted job.
- Do not use this project to bypass logins, paywalls, access controls or anti-bot protections.
