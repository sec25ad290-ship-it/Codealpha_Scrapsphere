
from flask import Flask, render_template, request, jsonify, Response
from bs4 import BeautifulSoup
from urllib.parse import urlparse
from urllib.robotparser import RobotFileParser
from datetime import datetime
import requests, csv, io, json, re

app = Flask(__name__)
app.secret_key = "change-this-secret-key"
records = []
jobs = []

def valid_url(value):
    p = urlparse(value)
    return p.scheme in ("http", "https") and bool(p.netloc)

def scrape_page(url, limit=100):
    if not valid_url(url):
        raise ValueError("Enter a valid URL beginning with http:// or https://")
    parsed = urlparse(url)
    robots_url = f"{parsed.scheme}://{parsed.netloc}/robots.txt"
    try:
        rp = RobotFileParser()
        rp.set_url(robots_url)
        rp.read()
        if not rp.can_fetch("ScrapeSphereBot", url):
            raise ValueError("This website's robots.txt does not allow this page to be scraped.")
    except ValueError:
        raise
    except Exception:
        # If robots.txt cannot be retrieved, continue cautiously with a single request.
        pass

    response = requests.get(
        url,
        headers={"User-Agent": "ScrapeSphereBot/1.0 (educational project)"},
        timeout=15
    )
    response.raise_for_status()
    if "text/html" not in response.headers.get("Content-Type", ""):
        raise ValueError("The URL did not return an HTML page.")
    soup = BeautifulSoup(response.text, "html.parser")
    title = soup.title.get_text(" ", strip=True) if soup.title else ""
    description_tag = soup.find("meta", attrs={"name": re.compile("^description$", re.I)})
    description = description_tag.get("content", "").strip() if description_tag else ""
    headings = [h.get_text(" ", strip=True) for h in soup.find_all(re.compile("^h[1-6]$"))]
    links = []
    for a in soup.find_all("a", href=True):
        href = a["href"].strip()
        if href.startswith(("http://", "https://")):
            links.append({"text": a.get_text(" ", strip=True)[:160], "url": href})
        if len(links) >= limit:
            break
    images = []
    for img in soup.find_all("img", src=True):
        images.append(img.get("alt", "").strip() or "Image")
        if len(images) >= limit:
            break
    paragraphs = [p.get_text(" ", strip=True) for p in soup.find_all("p") if p.get_text(" ", strip=True)]
    return {
        "title": title, "description": description,
        "headings": headings[:limit], "paragraphs": paragraphs[:limit],
        "links": links, "images": images[:limit],
        "url": url, "scraped_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }

@app.route("/")
def home():
    return render_template("index.html")

@app.post("/api/scrape")
def scrape():
    data = request.get_json(silent=True) or {}
    url = (data.get("url") or "").strip()
    try:
        result = scrape_page(url)
        job_id = len(jobs) + 1
        job = {"id": job_id, "url": url, "status": "Completed",
               "count": len(result["headings"]) + len(result["paragraphs"]) + len(result["links"]) + len(result["images"]),
               "time": result["scraped_at"]}
        jobs.insert(0, job)
        records.insert(0, result)
        return jsonify({"ok": True, "result": result, "job": job})
    except Exception as e:
        job = {"id": len(jobs) + 1, "url": url, "status": "Failed", "count": 0,
               "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"), "error": str(e)}
        jobs.insert(0, job)
        return jsonify({"ok": False, "error": str(e), "job": job}), 400

@app.get("/api/stats")
def stats():
    return jsonify({"jobs": len(jobs), "success": sum(j["status"] == "Completed" for j in jobs),
                    "failed": sum(j["status"] == "Failed" for j in jobs),
                    "records": sum(j.get("count", 0) for j in jobs), "history": jobs[:30]})

@app.get("/api/export/<kind>")
def export(kind):
    if kind == "json":
        return Response(json.dumps(records, indent=2), mimetype="application/json",
                        headers={"Content-Disposition": "attachment; filename=scrapesphere-data.json"})
    if kind == "csv":
        output = io.StringIO()
        writer = csv.DictWriter(output, fieldnames=["url", "title", "description", "headings", "paragraphs", "links", "images", "scraped_at"])
        writer.writeheader()
        for r in records:
            row = dict(r)
            for key in ("headings", "paragraphs", "links", "images"):
                row[key] = json.dumps(row.get(key, []), ensure_ascii=False)
            writer.writerow(row)
        return Response(output.getvalue(), mimetype="text/csv",
                        headers={"Content-Disposition": "attachment; filename=scrapesphere-data.csv"})
    return jsonify({"error": "Supported formats: csv, json"}), 400

if __name__ == "__main__":
    app.run(debug=True, port=5000)
